from django.contrib import admin
from movie.models import Movie
from import_export.admin import ImportExportModelAdmin
# Register your models here.
admin.site.register(Movie)
class MovieAdmin(ImportExportModelAdmin):
	list_display = ('name','actor','release_date','genres')

