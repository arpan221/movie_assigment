from django.shortcuts import render,HttpResponse,redirect
from movie.models import Movie
from .resources import MovieResource
from django.db.models import Q
from tablib import Dataset
import datetime
import os
from django.contrib import messages
# Create your views here.

def index(request):
	data = Movie.objects.filter(status="Active")
	context = {
        "data":data,

    }
    

	return render(request, 'index.html',context)

def addmovie(request):
    if request.method == "POST":
    	movie = Movie()
    	movie.name = request.POST.get('name')
    	movie.actor = request.POST.get('actor')
    	movie.release_date = request.POST.get('release_date')
    	movie.genres = request.POST.get('genres')
    	if len(request.FILES) != 0:
    		movie.poster_image = request.FILES['poster_image']
    	movie.save()
    	messages.success(request, ('Record Added Successfully....!!'))
    	return redirect("/")
    else:
    	data = Movie.objects.all()
    	context = {
    	"data":data
    	}
    	return render(request, 'index.html',context)
def moviedelete(request):
	if request.method =="POST" and request.POST.get('delete_id') != None:
		Movie.objects.filter(pk = request.POST.get('delete_id')).update(status = "Inactive")
		messages.success(request, ('Record Deleted Successfully....!!'))

		return redirect("/")
		

def update(request,id):
	if request.method == "GET":
		data = Movie.objects.filter(pk=id)
		context = {
        "data":data,
    	}
    
		return render(request, 'update.html',context)
	else:
		movie = Movie.objects.get(pk=id)
		if len(request.FILES) != 0:
			# if len(movie.poster_image) > 0:
			# 	os.remove(movie.poster_image.path)
			movie.poster_image = request.FILES['poster_image']
		movie.name = request.POST.get('name')
		movie.actor = request.POST.get('actor')
		release_date = request.POST.get('release_date')
		if release_date != "":
			movie.release_date = release_date
		movie.genres = request.POST.get('genres')
		movie.save()
		messages.success(request, ('Record Updated Successfully....!!'))
		return redirect("/")



def upload(request):
    if request.method == 'POST':
        person_resource = MovieResource()
        dataset = Dataset()
        new_persons = request.FILES['myfile']

        imported_data = dataset.load(new_persons.read(),format='xlsx')
        #print(imported_data)
        for data in imported_data:
        	print(data[1])
        	value = Movie(
        		data[0],
        		data[1],
        		 data[2],
        		 data[3],
        		 data[4],
        		 data[5],
        		 data[6],
        		)
        	value.save()
        messages.success(request, ('File Uploaded Successfully....!!'))
        return redirect("/")

def filter(request):
	name = request.GET['name']
	actor = request.GET['actor']
	release_date = request.GET['release_date']
	genres = request.GET['genres']
	if name != "":
		data = Movie.objects.filter(Q(status="Active") ,Q(name=name ) | Q(actor= actor) | Q(genres=genres))
	if actor != "":
		data = Movie.objects.filter( Q(status="Active") ,Q(actor= actor) | Q(genres=genres) | Q(name=name ))
	if genres != "":
		data = Movie.objects.filter(Q(status="Active") ,Q(genres=genres) | Q(name=name ) |Q(actor= actor))

	if release_date != "":
		data = Movie.objects.filter(Q(status="Active"), Q(name=name )| Q(actor= actor) |Q(release_date=release_date) | Q(genres=genres))

	if release_date == "":
		data = Movie.objects.filter( Q(status="Active"), Q(genres=genres) | Q(name=name )| Q(actor= actor))


	context = {
        "data":data,

    }

	return render(request, 'index.html',context)











