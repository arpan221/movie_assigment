from django.db import models
from model_utils import Choices

# Create your models here.
class Movie(models.Model):
    name = models.CharField(max_length=122)
    actor = models.CharField(max_length=122)
    genres = models.TextField()
    poster_image = models.ImageField(blank=True, upload_to='movie_poster', default='movie_poster/no-image.jpg')
    release_date = models.DateField()
    STATUS = Choices('Active', 'Inactive')
    status = models.CharField(choices=STATUS, default=STATUS.Active, max_length=20)

    def __str__(self):
        return self.name