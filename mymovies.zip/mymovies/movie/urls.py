from django.contrib import admin
from django.urls import path
from movie import views

urlpatterns = [
    path('', views.index, name="movie"),
    path('save', views.addmovie, name="movie"),
    path('delete', views.moviedelete, name="movie"),
    path('update/<int:id>',views.update, name="movie"),
    path('upload', views.upload, name="movie"),
    path('filter', views.filter, name="filter"),
]